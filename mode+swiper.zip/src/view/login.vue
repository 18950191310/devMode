<template>
  <div>login</div>
  <swiper></swiper>
</template>

<script>
export default {
  name: "demo",
  props: {},
  components: {},
};
</script>
<script setup>
import Swiper from "../components/Carousel.vue";
</script>

<style scoped>
.swiper {
  width: 600px;
  height: 300px;
}
</style>
